package Dark;

import MainPackage.MyColors;
import MainPackage.MyFonts;
import MainPackage.MyIcons;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class DarkMusicInfo extends JPanel {
    public DarkMusicInfo(){
        super();
        //setLayout(new GridLayout(3,1));
        setLayout(new BorderLayout());
        setBackground(MyColors.DarkFooter);
        JCheckBox like = new JCheckBox();
        like.setBackground(MyColors.DarkFooter);
        like.setForeground(MyColors.DarkTextColor);
        like.setIcon(MyIcons.DarkMagnifier);
        like.setBorderPaintedFlat(false);
        like.setBorder(new EmptyBorder(0,0,0,20));
        //add(like,BorderLayout.WEST);

        JPanel musicNameAndArtistPanel = new JPanel(new GridLayout(2,1));//music name

        JLabel musicName = new JLabel("Something to remind you");
        musicName.setFont(MyFonts.arialBold);
        musicNameAndArtistPanel.setBackground(MyColors.DarkFooter);
        musicName.setForeground(MyColors.DarkTextColor);
        musicNameAndArtistPanel.add(musicName );
        JPanel artistNamePanel = new JPanel(new BorderLayout());//artist name
        JLabel artistName = new JLabel("Staind");
        artistName.setFont(MyFonts.arial);
        artistNamePanel.setBackground(MyColors.DarkFooter);
        artistName.setForeground(MyColors.DarkTextColor);
        artistNamePanel.add(artistName);
//        add(artistNamePanel , BorderLayout.SOUTH);
        musicNameAndArtistPanel.add(artistName );
        add(musicNameAndArtistPanel, BorderLayout.CENTER);


    }
}
