package Dark;

import MainPackage.MyColors;
import MainPackage.MyFonts;
import MainPackage.MyIcons;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;

public class DarkMainPanel extends JPanel {
    private JPanel title;
    private JPanel body;
    private JPanel homePlayListPanel;
    public DarkMainPanel(String headerName){
        setLayout(new BorderLayout());
//        title = new JPanel(new GridLayout(1,3));
        title = new JPanel(new BorderLayout());
        title.setBackground(MyColors.DarkMenu);
        JLabel leftLowPoly = new JLabel(MyIcons.DarkTitleLeft);
        leftLowPoly.setBackground(Color.magenta);
        title.add(leftLowPoly , BorderLayout.WEST);
        JLabel RightLowPoly = new JLabel(MyIcons.DarkTitleRight);
        //title.add(RightLowPoly , BorderLayout.EAST);
        JLabel titleName = new JLabel();
        JPanel titleNamePanel = new JPanel(new BorderLayout());
        titleName.setForeground(MyColors.DarkTextColor);
        titleName.setBackground(MyColors.DarkTextColor);
        titleName.setText(headerName);
        titleNamePanel.setBackground(MyColors.DarkMenu);
        titleName.setFont(MyFonts.heavyTitle);
        titleNamePanel.add(titleName, BorderLayout.WEST);
        title.add(titleNamePanel , BorderLayout.CENTER);
        add(title, BorderLayout.NORTH);
        ///////////////////////////////////////////////////////////
        body = new JPanel();
        body.setBackground(MyColors.DarkBackground);

        if(headerName.equals("HOME")){
            body.setLayout(new GridLayout(3,1));
            homePlayListPanel = new JPanel();
            homePlayListPanel.setBorder(new TitledBorder(new LineBorder(MyColors.DarkTextColor, 2), "Title String"));
            homePlayListPanel.setBackground(MyColors.DarkBackground);
            body.add(homePlayListPanel);
        }

        add(body, BorderLayout.CENTER);
    }
}
