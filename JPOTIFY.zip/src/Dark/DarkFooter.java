package Dark;

import MainPackage.MyColors;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class DarkFooter extends JPanel {
    public DarkFooter(boolean playOrPaused){
        super();
        setBackground(MyColors.DarkFooter);
//        setLayout(new BorderLayout());
        setLayout(new GridLayout(1,3));
        setBackground(MyColors.DarkFooter);

        DarkMusicInfo musicInfo = new DarkMusicInfo();
        musicInfo.setBorder(new EmptyBorder(20,20,20,0));
        add(musicInfo, BorderLayout.WEST);

        DarkMusicController musicController = new DarkMusicController(playOrPaused);
        musicController.setBorder(new EmptyBorder(0,0,10,0));
        add(musicController, BorderLayout.CENTER);

        DarkVolumePanel volumePanel = new DarkVolumePanel();
        volumePanel.setBorder(new EmptyBorder(16,0,0,20));
        add(volumePanel, BorderLayout.EAST);
    }
}
